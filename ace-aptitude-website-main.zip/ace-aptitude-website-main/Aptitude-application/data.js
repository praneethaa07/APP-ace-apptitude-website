var jsonData = [
    {
       "q" : "Excluding stoppages, the speed of a bus is 54 kmph and including stoppages, it is 45 kmph. For how many minutes does the bus stop per hour?",
       "opt1" : "9",
       "opt2" : "10",
       "opt3" : "12",
       "answer" : "10"
    },
    {
        "q" : "If a person walks at 14 km/hr instead of 10 km/hr, he would have walked 20 km more. The actual distance travelled by him is:",
        "opt1" : "50 km",
        "opt2" : "56 km",
        "opt3" : "70 km",
        "answer" : "50 km"
     },
     {
        "q" : "A jogger is running at speed of 15km/hr, in what time he will cross a track of length of 300 meters?",
        "opt1" : "74",
        "opt2" : "96",
        "opt3" : "104",
        "answer" : "96"
     },
     {
       "q" : "If a man runs at 24km/hr instead of 20km/hr he could run 40km more.Find the actual distance.",
       "opt1" : "221",
       "opt2" : "121",
       "opt3" : "200",
       "answer" : "200"
    },
    {
        "q" : "The ratio between the speeds of two cars is 5:8 if the first car covers 200km in 2hours.Find the speed of the second car",
        "opt1" : "150",
        "opt2" : "120",
        "opt3" : "160",
        "answer" : "120"
     },
     {
        "q" : "A man covers first 48km of his journey in 40 minutes and next 32km in 30 minutes.Find his average speed?",
        "opt1" : "65",
        "opt2" : "73",
        "opt3" : "64",
        "answer" : "64"
     }
     
     
     
];